import { useState } from "react"
import { useNavigate } from "react-router-dom"
const SignIn = () => {
    const [username, setUsername] = useState('')
    const [password, setPassword] = useState('')
    const userdata = {
        username: username,
        password: password
    }

    const navigate = useNavigate()
    const onSubmitHandler = (event) => {
        event.preventDefault()

        var axios = require('axios');
        var data = JSON.stringify(userdata);

        var config = {
            method: 'post',
            url: 'https://reqres.in/api/login',
            headers: {
                'Content-Type': 'application/json'
            },
            data: data
        };

        axios(config)
            .then(function (response) {
                console.log(JSON.stringify(response.data));
                navigate("/dashboard")
            })
            .catch(function (error) {
                console.log(error);
            });

    }
    return (
        <>
            <div className="container-left">

                <h3> Sign-In-Form</h3>
                <div className="img-container">
                    <img src="https://th.bing.com/th/id/OIP.Kf-A4bhyw6NFAggbsk3cdwHaIU?w=136&h=180&c=7&r=0&o=5&dpr=1.18&pid=1.7" alt="user-log" />
                </div>
            </div>
            <div className="Signup_form">


                <form action="" onSubmit={onSubmitHandler}>
                    <img className="Signup_form_img" src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSqx1eRUoVGwxOUkZby1LRtBPhKHN9FphU6hg&usqp=CAU" alt="user-login" />
                    <label for="fname">First name:</label><br></br>
                    <input type="text" id="fname" name="fname" onChange={(e) => { setUsername(e.target.value) }} value={username} required /><br></br>
                    <label for="lname">Last name:</label><br></br>
                    <input type="password" id="lname" name="lname" onChange={(e) => { setPassword(e.target.value) }} value={password} required /><br></br>
                    <a href="/signup"><button type="button"  >SignUp</button></a>
                    <button type="submit"  >SignIn</button>
                </form>

            </div>

        </>
    )
}
export default SignIn