import { Route, Routes } from "react-router-dom"
import Dashboard from "./Dashboard"
import SignIn from "./Signin"
import SignUp from "./Signup"

const Navigation=()=>{
    return(

        <Routes>
            <Route path="/" element={<SignIn />} />
                <Route path="signup" element={<SignUp />} />
                <Route path="dashboard" element={<Dashboard />} />

        </Routes>
    )
}
export default Navigation